package com.example.blechatdemo;

import static com.example.blechatdemo.server.GattService.CHAR_UUID;
import static com.example.blechatdemo.server.GattService.SERVICE_UUID;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import com.clj.fastble.BleManager;
import com.clj.fastble.callback.BleMtuChangedCallback;
import com.clj.fastble.callback.BleWriteCallback;
import com.clj.fastble.data.BleDevice;
import com.clj.fastble.exception.BleException;
import com.example.blechatdemo.databinding.ActivityChatBinding;
import com.example.blechatdemo.file.CopyFileToAppDirTask;
import com.example.blechatdemo.file.FileHelper;
import com.example.blechatdemo.file.FileTaskListener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import pub.devrel.easypermissions.EasyPermissions;

public class ChatActivity extends AppCompatActivity implements EasyPermissions.PermissionCallbacks, FileTaskListener {

    private static final int EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE = 120;
    private ActivityChatBinding binding;
    private ChatAdapter adapter;
    private List<Message> messageList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());//The binding.getRoot() method returns the root view of the layout file
        initView();
        initBtnAction();
        initAdapter();
        listenIncomingMessage();
        askPermission();

        BleManager.getInstance().setMtu(ChatService.getInstance().connectedDevice, 512 , new BleMtuChangedCallback() {
            @Override
            public void onSetMTUFailure(BleException exception) {
                Log.d("onSetMTUFailure", "" + exception);

            }

            @Override
            public void onMtuChanged(int mtu) {
                Log.d("onMtuChanged", "" + mtu);
            }
        });
    }

    private void askPermission() {
        if (!EasyPermissions.hasPermissions(this, Manifest.permission.READ_EXTERNAL_STORAGE) || !EasyPermissions.hasPermissions(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            String[] perm = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
            EasyPermissions.requestPermissions(this, "Permission required to access your documents", EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE, perm);
        } else {
            //showFilePicker(); //just doubleslashed
        }
    }

    ActivityResultLauncher<Intent> fileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
//                        String path = FileHelper.getPath(result.getData().getData(),ChatActivity.this);
//                        Log.d("PAth",path);
                        new CopyFileToAppDirTask(ChatActivity.this, ChatActivity.this).execute(result.getData().getData());

                    }
                }
            });

    private void showFilePicker() {
        //new code picking file
        if (!EasyPermissions.hasPermissions(this, Manifest.permission.READ_EXTERNAL_STORAGE) || !EasyPermissions.hasPermissions(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            String[] perm = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
            EasyPermissions.requestPermissions(this, "Permission required to access your documents", EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE, perm);
            return;
        }
        Intent chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
        chooseFile.setType("*/*"); //"*/*" instead of text/plain to select any file
        chooseFile = Intent.createChooser(chooseFile, "Choose a file");
        fileLauncher.launch(chooseFile);
    }

    @Override
    public void onPermissionsGranted(int requestCode, List perms) {
        // Add your logic here
        showFilePicker();
    }

    @Override
    public void onPermissionsDenied(int requestCode, List perms) {
        // Add your logic here
    }

    private void initView(){
        BleDevice device = ChatService.getInstance().connectedDevice;
        if (device == null){
            return;
        }
        String chatName = "";
        if(!TextUtils.isEmpty(device.getName())){
            chatName = device.getName();
        }else{
            chatName = device.getDevice().getAddress();
        }
        binding.chatName.setText(chatName);
    }
    private void initBtnAction(){
        binding.backBtn.setOnClickListener(v->{
            ChatService.getInstance().disconnect();
            onBackPressed();
        });
        binding.sendBtn.setOnClickListener(v->{
            sendMsg();
        });
        binding.attachBtn.setOnClickListener(v -> {
            //askPermission();
            showFilePicker();
        });
    }
    private void initAdapter(){
        adapter = new ChatAdapter(messageList, new ChatAdapter.ChatItemListener() {//new added
            @Override
            public void onItemClicked(Message message) {
                if (message.getConteType().equals("FILE")) {
                    openFile(message);
                }
            }
        });
        LinearLayoutManager manager = new LinearLayoutManager(this);
        manager.setOrientation(RecyclerView.VERTICAL);
        binding.listview.setLayoutManager(manager);
        binding.listview.setAdapter(adapter);
    }

    private Message buildMessage() { //constructs a Message object
        BleDevice receiver = ChatService.getInstance().connectedDevice;
        Message message = new Message();
        message.setText(binding.editText.getText().toString());
        message.setSender(ChatService.getInstance().currentAddress);
        message.setSenderName("");
        message.setReceiverName(receiver.getName());
        message.setConteType("TEXT"); //new code
        message.setReceiver(receiver.getDevice().getAddress());
        return message;
    }
    private void sendMsg(){ //sending a message using the ChatService.
        if(TextUtils.isEmpty(binding.editText.getText()) ) {
            return;
        }
        Message m = buildMessage();
        addMessage(m);
        binding.editText.setText("");

        ChatService.getInstance().sendMessage((m.getText()), new BleWriteCallback() {
            @Override
            public void onWriteSuccess(int current, int total, byte[] justWrite) {

            }

            @Override
            public void onWriteFailure(BleException exception) {

            }
        });
    }

    private void addMessage(Message message){ //constructed message is added to the chat or message list
        messageList.add(message);
        adapter.reload(messageList);
    }

    private void listenIncomingMessage(){ // listener for incoming messages using the ChatService
        ChatService.getInstance().setChatCallback(new ChatService.ChatListener() {
            @Override
            public void onMessageReceived(String text) {
                Log.d("onMessageReceived",text);

                BleDevice receiver = ChatService.getInstance().connectedDevice;
                Message message = new Message();
                message.setText(text);
                message.setSender(receiver.getDevice().getAddress());
                message.setSenderName("");
                message.setReceiverName("");
                message.setConteType("TEXT");//new code
                message.setReceiver(ChatService.getInstance().currentAddress);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        addMessage(message);
                    }
                });
            }

            @Override //new code
            public void onFileReceived(String path) {
                BleDevice receiver = ChatService.getInstance().connectedDevice;
                Message message = new Message();
                message.setText(path);
                message.setConteType("FILE");
                message.setSender(receiver.getDevice().getAddress());
                message.setSenderName("");
                message.setReceiverName("");
                message.setReceiver(ChatService.getInstance().currentAddress);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        addMessage(message);
                    }
                });
            }
        });
    }

    //new code
    private void sendNotifFileWritedone(){
        ChatService.getInstance().sendFileNotificationMessage("#FILE_END".getBytes(), new BleWriteCallback() {
            @Override
            public void onWriteSuccess(int current, int total, byte[] justWrite) {

            }

            @Override
            public void onWriteFailure(BleException exception) {

            }
        });
    }
    int totalBytesSent = 0;
    private void sendfile(File file){ // sending a file using the ChatService
        byte[] data = FileHelper.convertBytes(file);
        if (data == null) {
            Log.e("sendFile", "Failed to read file");
            return;
        }
        Log.d("onWriteInit", "file size "+data.length);
        totalBytesSent = 0;
        ChatService.getInstance().sendFileMessage(data, new BleWriteCallback() {
            @Override
            public void onWriteSuccess(int current, int total, byte[] justWrite) {
                Log.d("onWriteSuccess", "current "+total);
                Log.d("onWriteSuccess", "total "+total);
                Log.d("onWriteSuccess", "justWrite "+justWrite.length);
                totalBytesSent += justWrite.length;
                if (totalBytesSent == data.length){
                    sendNotifFileWritedone();
                }
                Log.d("onWriteSuccess", "totalBytesSent "+totalBytesSent);

            }

            @Override
            public void onWriteFailure(BleException exception) {
                Log.d("onWriteFailure", "Erorr "+exception);

            }
        });

        BleDevice receiver = ChatService.getInstance().connectedDevice;
        Message message = new Message();
        message.setText(file.getPath());
        message.setConteType("FILE");
        message.setSender(ChatService.getInstance().currentAddress);
        message.setSenderName("");
        message.setReceiverName("");
        message.setReceiver(receiver.getDevice().getAddress());
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                addMessage(message);
            }
        });
    }

    @Override //new code
    public void onFileReceived(File file) {

        ChatService.getInstance().sendFileNotificationMessage("#FILE_INIT".getBytes(), new BleWriteCallback() {
            @Override
            public void onWriteSuccess(int current, int total, byte[] justWrite) {
                sendfile(file);
            }

            @Override
            public void onWriteFailure(BleException exception) {

            }
        });

        //old code
       // byte[] data = FileHelper.convertBytes(file);
        //
        //        BluetoothGattCharacteristic characteristic = BleManager.getInstance().getBleBluetooth(ChatService.getInstance().connectedDevice).getBluetoothGatt().getService(SERVICE_UUID).getCharacteristic(CHAR_UUID);
        //        characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
        //        characteristic.setValue(data);
        //
        //        BluetoothGatt gatt = BleManager.getInstance().getBluetoothGatt(ChatService.getInstance().connectedDevice);
        //        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
        //
        //        }
        //        gatt.writeCharacteristic(characteristic);

     /*   BleManager.getInstance().getBluetoothGatt(ChatService.getInstance().connectedDevice).writeCharacteristic()
        ChatService.getInstance().sendFileMessage(data, new BleWriteCallback() {
            @Override
            public void onWriteSuccess(int current, int total, byte[] justWrite) {
                Log.d("onWriteSuccess", "Size "+total);

            }

            @Override
            public void onWriteFailure(BleException exception) {
                Log.d("onWriteFailure", "Erorr "+exception);

            }
        }); */

    }

    public void openFile(Message message) {
        try {
            File file = new File(message.getText());
            Uri photoURI = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(photoURI, "*/*");
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            // no Activity to handle this kind of files
        }
    }
}