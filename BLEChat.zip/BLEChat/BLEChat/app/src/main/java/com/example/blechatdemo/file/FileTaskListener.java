package com.example.blechatdemo.file;

import java.io.File;

public interface FileTaskListener {
    void onFileReceived( File file);
}
